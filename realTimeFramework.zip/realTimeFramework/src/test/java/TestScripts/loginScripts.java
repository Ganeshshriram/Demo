package TestScripts;

import java.io.IOException;

import org.testng.annotations.Test;

import Pages.ForgetPasswordPage;
import Pages.LoginPage;
import WebDriverFactory.DriverInitialization;

public class loginScripts extends DriverInitialization {
	
	@Test
	public void NegativeLoginFunctionality() throws IOException {
		driver = driverInitialization();
		driver.get("https://www.facebook.com");
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterEmailAdress("dinesh@gmail.com");
		loginPage.enterPassword("qwerty");
		loginPage.clickLogin();
		driver.quit();
	}
	
	@Test
	public void verifyNoSearchResultErrorMessageAppears() throws IOException{
		driver = driverInitialization();
		driver.get("https://www.facebook.com");
		LoginPage loginPage = new LoginPage(driver);
		loginPage.clickForgetPasswordLink();
		ForgetPasswordPage forgetPasswordPage = new ForgetPasswordPage(driver);
		forgetPasswordPage.enterRecoveryEmail("recov");
		forgetPasswordPage.clickSubmit();
		forgetPasswordPage.verifyNoSearchResultsErrorMessage();
		driver.quit();
	}

}
