package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import WebDriverFactory.DriverInitialization;
import utilities.utilities;

public class LoginPage extends DriverInitialization {
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	utilities utilities = new utilities();
	///////////////////WEBELEMENTS//////////////////////////////////
	@FindBy(how=How.ID , using="email")
	WebElement fldEmail;
	
	@FindBy(how=How.ID , using="pass")
	WebElement fldPassword;
	
	@FindBy(how=How.NAME , using="login")
	WebElement btnLogin;
	
	@FindBy(how=How.LINK_TEXT , using="Forgotten password?")
	WebElement lnkForgetPassword;
	
	/////////////////REUSABLE METHODS/////////////////////////////////////
	
	/**
	 * @author Ganesh
	 * @param emailId
	 * @summary enters Email Adress
	 */
	public void enterEmailAdress(String emailId) {
		fldEmail.sendKeys(emailId);
	}
	
	/**
	 * @author Ganesh
	 * @param password
	 * @summary enters Password
	 */
	public void enterPassword(String password) {
		fldPassword.sendKeys(password);
	}
	
	/**
	 * 
	 */
	public void clickLogin() {
		btnLogin.click();
	}
	
	public void clickForgetPasswordLink() {
		lnkForgetPassword.click();
		utilities.waitTillVisibilityLocated(By.xpath("//h2[@class='uiHeaderTitle']"));
	}
	
	
	
	
	
	

}
