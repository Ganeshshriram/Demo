package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import WebDriverFactory.DriverInitialization;

public class ForgetPasswordPage extends DriverInitialization {

	public ForgetPasswordPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	///////////////////WEBELEMENTS//////////////////////////////////
	@FindBy(how=How.ID, using="identify_email")
	WebElement fldRecoveryEmail;
	
	@FindBy(how=How.ID, using="did_submit")
	WebElement btnSubmit;
	
	@FindBy(how=How.XPATH, using="//div[text()='No search results']")
	WebElement errMsgNoSearchResults;
	
/////////////////REUSABLE METHODS/////////////////////////////////////
	
	public void enterRecoveryEmail(String recoveryEmail) {
		fldRecoveryEmail.sendKeys(recoveryEmail);
	}
	
	public void clickSubmit() {
		btnSubmit.click();
	}
	
	public void verifyNoSearchResultsErrorMessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='No search results']")));
		String reqText = errMsgNoSearchResults.getText();
		Assert.assertEquals(reqText, "No search results");
	}
}
